package pb_22130833_proyecto_02;

class totalVendido {

    private String nombre;
    private perfumes invInicial;
    private perfumes invFinal;

    public totalVendido() {
        nombre = "NO-ID";
        invInicial = new perfumes();
        invFinal = new perfumes();
    }

    public totalVendido(String nombre, perfumes invInicial, perfumes invFinal) {
        this.nombre = nombre;
        this.invInicial = invInicial;
        this.invFinal = invFinal;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public perfumes getInvInicial() {
        return invInicial;
    }

    public void setInvInicial(perfumes invInicial) {
        this.invInicial = invInicial;
    }

    public perfumes getInvFinal() {
        return invFinal;
    }

    public void setInvFinal(perfumes invFinal) {
        this.invFinal = invFinal;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", inicial: " + invFinal + ", final: " + invFinal;
    }

    public perfumes totalVendido() {
        return invInicial.resta(invFinal);
    }
    
}
