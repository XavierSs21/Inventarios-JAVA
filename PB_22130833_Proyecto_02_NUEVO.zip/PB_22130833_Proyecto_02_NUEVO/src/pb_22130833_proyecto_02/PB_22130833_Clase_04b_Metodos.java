package pb_22130833_proyecto_02;

import javax.swing.JTable;

class metodos {

    private perfumes[] indice;

    public metodos() {
        indice = new perfumes[5];
    }

    public metodos(int n) {
        indice = new perfumes[n];
    }

    public perfumes getperfumes(int posicion) {
        return indice[posicion];
    }

    public void setnombreKioscos(int posicion, perfumes nombre) {
        indice[posicion] = nombre;
    }

    public void mostrar(JTable modelo) {

        perfumes invInicial = new perfumes();
        perfumes invFinal = new perfumes();
        perfumes resta;
        perfumes suma = new perfumes();

        for (int r = 0; r < modelo.getRowCount(); r++) {
            //inventario invInicialcial 
            modelo.setValueAt(indice[r].getKiosco(), r, 0);
            
            modelo.setValueAt(indice[r].getBarril(), r, 1);
            modelo.setValueAt(indice[r].getGalon(), r, 2);
            modelo.setValueAt(indice[r].getPinta(), r, 3);
            modelo.setValueAt(indice[r].getOnza(), r, 4);
            
            //inventario invFinalal
            modelo.setValueAt(indice[r].getBarril(), r, 5);
            modelo.setValueAt(indice[r].getGalon(), r, 6);
            modelo.setValueAt(indice[r].getPinta(), r, 7);
            modelo.setValueAt(indice[r].getOnza(), r, 8);

            resta = invInicial.resta(invFinal); //restaultado de ventas
            suma = suma.suma(resta); //suma todas las ventas

            modelo.setValueAt(resta, r, 9);
            //muestra el restaultado de la venta de cada kiosco
        }

    }
    

}
