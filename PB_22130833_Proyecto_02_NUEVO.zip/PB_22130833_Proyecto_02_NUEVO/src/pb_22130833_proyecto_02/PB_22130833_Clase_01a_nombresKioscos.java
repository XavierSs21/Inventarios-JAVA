package pb_22130833_proyecto_02;

import java.util.Random;

class nombresKioscos {
    
    private static String [] sucursal = {"Galerías", "4 Caminos", "Intermall",
     "Plaza Imagen", "Fundadores","Almanara",
     "Paseo Independencia", "Plaza 505", "Plaza LaViña", 
     "Plaza Viñedos"};
    
    private static Random rd = new Random();
    // Método para obtener un tipo de sucursalsco aleatorio

    public static String nextSucursal(){
        return sucursal[rd.nextInt(sucursal.length)];
    }
}
