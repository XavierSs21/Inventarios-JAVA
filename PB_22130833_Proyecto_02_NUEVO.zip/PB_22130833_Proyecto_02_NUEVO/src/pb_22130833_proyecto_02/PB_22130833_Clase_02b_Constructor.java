package pb_22130833_proyecto_02;

class perfumes {

    private String kiosco;
    private int barril;
    private int galon;
    private int pinta;
    private int onza;

    //Constructor por default
    public perfumes() {

        barril = galon = pinta = onza = 0;
        kiosco = "No-ID";
    }

    //Constructor parametrizado
    public perfumes(int barril, int galon, int pinta, int onza) {
        this.barril = barril;
        this.galon = galon;
        this.pinta = pinta;
        this.onza = onza;
    }

    //Para poder acceder a los atributos
    public perfumes(perfumes getperfumes) {
        barril = getperfumes.barril;
        galon = getperfumes.galon;
        pinta = getperfumes.pinta;
        onza = getperfumes.onza;
    }

    //Getters and Setters
    public String getKiosco() {
        return kiosco;
    }

    public void setKiosco(String kiosco) {
        this.kiosco = kiosco;
    }

    public int getBarril() {
        return barril;
    }

    public void setBarril(int barril) {
        this.barril = barril;
    }

    public int getGalon() {
        return galon;
    }

    public void setGalon(int galon) {
        this.galon = galon;
    }

    public int getPinta() {
        return pinta;
    }

    public void setPinta(int pinta) {
        this.pinta = pinta;
    }

    public int getOnza() {
        return onza;
    }

    public void setOnza(int onza) {
        this.onza = onza;
    }

    //castear el metodo toString()
    public String toString() {
        return "Bar: " + barril + " Gal: " + galon + "  Pin: " + pinta + " Onz: " + onza;
    }

    //Formula para obtener las Ventas
    public int calcularOnzas() {
        return (barril * 5376) + (galon * 128) + (pinta * 16) + onza;
    }

    public perfumes resta(perfumes p) {
        
        int totalOnz = calcularOnzas() - p.calcularOnzas();

        int barr = totalOnz / 5376;
        int restoOnz = totalOnz % 5376;
        int gal = restoOnz / 128;
        int resto = restoOnz % 128;
        int pin = resto / 16;
        int onz = resto % 16;

        perfumes resultante = new perfumes(barr, gal, pin, onz);
        return resultante;
    }

    public perfumes suma(perfumes p) {

        int totalOnza = calcularOnzas() + p.calcularOnzas();

        int barr = totalOnza / 5376;
        int sobranteOnza = totalOnza % 5376;
        int gal = sobranteOnza / 128;
        int sobrante = sobranteOnza % 128;
        int pin = sobrante / 16;
        int onz = sobrante % 16;

        perfumes resultante = new perfumes(barr, gal, pin, onz);

        return resultante;
    }

}
